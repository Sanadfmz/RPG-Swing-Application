package nl.rug.ai.oop.rpg.general;

/**
 * A class if producable if it can be produced from a factory class.
 * 
 * @author Matthijs
 */
public interface Producable {

}
