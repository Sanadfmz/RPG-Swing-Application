package nl.rug.ai.oop.rpg.battles.model.entities.party;

import nl.rug.ai.oop.rpg.battles.model.entities.Party;

/**
 * Party class for battles
 * 
 * @author Matthijs
 * @author Niclas
 */
public class MainParty extends Party {
}
