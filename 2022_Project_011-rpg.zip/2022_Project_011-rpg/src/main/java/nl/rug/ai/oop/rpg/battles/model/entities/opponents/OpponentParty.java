package nl.rug.ai.oop.rpg.battles.model.entities.opponents;
import nl.rug.ai.oop.rpg.battles.model.entities.Party;

/**
 * Party of opponents
 * 
 * @author Matthijs
 * @author Niclas
 */
public class OpponentParty extends Party {
}
