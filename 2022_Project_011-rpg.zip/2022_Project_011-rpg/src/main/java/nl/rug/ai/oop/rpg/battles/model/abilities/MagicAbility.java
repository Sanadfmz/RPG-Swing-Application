package nl.rug.ai.oop.rpg.battles.model.abilities;

/**
 * Used to distinguish abilities
 * @author Matthijs
 */
public abstract class MagicAbility extends Ability {
}
